MS 33558 truetype font
April 22, 2000
Beta 1.0

Description:
------------

The included truetype font is my version of MS33558, the Military Standard for the "Standard form of Numerals and letters for Aircraft Instrument Dials". It was traced off of a fax I recieved. The fax was distorted, and I cleaned it up as best I could. I'm still not happy with some of the lettering, though. If anyone could send me a better copy of this standard I'll be happy to update the font in order to ensure the highest accuracy. The font has upper and lower case letters repeated, because there isn't any lowercase lettering defined in the standard.

I'm open to any suggestions for updates. Contact me at the addresses below.

This font was created using Autocad 14 and Coreldraw 9.0.

Installation:
-------------

The easiest way to install this font is to extract it into the C:\WINDOWS\FONTS directory under Windows 95/98. Once installed, the font should show up in any application that allows you to use truetype fonts. For other operating systems, please refer to the documentation for your particular system. 

Copyright and Distribution
--------------------------

This font is released as Postcardware. Copyright (C) Derek Higgs.  As Postcardware you are permitted to distribute this archive subject to the following conditions,

- The archive must be distributed without modification to the contents of the archive. Redistributing this archive with any files added, removed or modified is prohibited.

- The inclusion of any individual file from this archive in another archive without the prior permission of the author is prohibited.

- No charge may be made for this archive other than that to cover the cost of its distribution. If a fee is charged it must be made clear
to the purchaser that the archive is freeware and that the fee is to cover the distributor's costs of providing the archive.

- If you like the font and use it in a project, please tell me what you have used it for on a postcard! Mail it to me at the address below.

- The authors' rights and wishes concerning this archive must be respected.


There are no warranties with this product, either expressed or implied. It is supplied "as is". It should not mess up your system (it's a font!).


Derek Higgs
6516 Ellesmere Drive
Knoxville TN 37921

dhiggs@simpits.com